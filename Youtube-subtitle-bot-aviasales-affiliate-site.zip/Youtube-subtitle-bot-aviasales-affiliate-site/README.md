# Youtube-subtitle-bot
A telegram bot that extract the subtitle from the youtube video links. It can also translate the subtitle to another languages. It provide different format to downlad subtitle file ie: SRT and VTT. Star the repo if you liked this bot.

# Want to use the bot?
Click here -> [@ytsubtitle_bot](https://t.me/ytsubtitle_bot)

# Contribute
Though there isn't much to impove or enhance in this simple bot but any suggestion or enhancement request will be appreciated.
